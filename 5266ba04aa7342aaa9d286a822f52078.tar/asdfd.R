

germanyst <- read_csv("all_station.csv")
tt <- ggplot(titanic,aes(PassengerClass))
fSStartWithB <- filter(germanyst, (federalState=="Bayern" | federalState == "Bremen" | federalState == "Berlin" | federalState == "Brandenburg" | federalState == "Baden-Wurttemberg"))
federalState <- ggplot(fSStartWithB,aes(y = federalState))
category <- ggplot(fSStartWithB,aes(y = category))
federalState + geom_bar(aes(fill = federalState))
federalState + geom_bar(aes(fill = regionalbereichName))
