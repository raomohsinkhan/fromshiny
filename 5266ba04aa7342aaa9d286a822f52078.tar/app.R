library(shiny)
library(shinydashboard)
library(tidyverse)
library(ggplot2)
titanic <- read_csv("Titanic_Data.csv")
germanyst <- read_csv("all_station.csv")
tt <- ggplot(titanic,aes(PassengerClass))
fSStartWithB <- filter(germanyst, (federalState=="Bayern" | federalState == "Bremen" | federalState == "Berlin" | federalState == "Brandenburg" | federalState == "Baden-Wurttemberg"))
federalState <- ggplot(fSStartWithB,aes(y = federalState))
category <- ggplot(fSStartWithB,aes(y = category))
myintro <- "Hello! my name is Rao Mohsin I’m from Karachi, Pakistan, I’m a Computer System Engineer Experienced in different business Intelligence tools and technologies e.g. Oracle BI (OBIEE),
Expertise in Advanced/Complex PL/SQL
Expertise building ETL processes from scratch
Exposure to BI tools (OBIEE and OBIA) with Oracle E-Business Suite as a source
Strong relational database modeling (SQL Server, Oracle, MySQL)
Experience with OBIA BI Apps ETL objects.
Experience with BI Publisher, Oracle Data Integrator (ODI) and Informatica, MS SQL Server, Oracle, Machine learning

Good programming experience in C#.Net , VB.Net, Access VBA, Java,Servlet,ASP (.NET and Classic) Strong Database development experience in writing functions,procedures, triggers and views in MSSQL

Personal Strengths: Adaptability, Communication, Quick learner, Research, Innovation.

Tools
ETL Development (Informatica, Oracle Data Integrator)
BI Publisher (with Siebel CRM, Oracle EBS)
Data warehouse architecture
OBIEE Answers (Direct Database Request)
QlikView
CRM (Siebel,Zoho)
Data Mining (Oracle Data Miner, RapidMiner) , I hope you enjoy reading my posts and find them useful."

sidebar <- dashboardSidebar(
    sidebarMenu(
        menuItem("Victim", tabName = "victim"),
        menuItem("Trafficker", tabName = "trafficker")
        ,menuItem("Rao Mohsin", tabName = "raomohsin")
        ,menuItem("Titanic RMD", tabName = "titanicrmd1")
        ,menuItem("Germany RMD 1", tabName = "germanyrmd1")
    )
)

body <- dashboardBody(
    tabItems(
        tabItem(tabName = "victim",
                h2("Victim tab")
        ),
        
        tabItem(tabName = "trafficker",
                h2("Trafficker tab")
                ,box(
                    title = "Inputs", status = "warning",
                    "Box content here", br(), "More box content",
                    sliderInput("bins", "Slider input:", 1, 100, 50),
                    textInput("text", "Text input:")
                    ,plotOutput("irisplot")
                )
        )
        ,tabItem(tabName = "raomohsin",
                h2("rao mohsin")
                ,br(),br()
                
                ,box(
                    title = "Introduction", width = "100%"  , status = "warning",myintro,
                    "Box content here", br(), "More box content"
                )
                ,br()
                ,box(
                    title = "Introduction", width = "100%"  , status = "warning",myintro,
                    "Box content here", br(), "More box content"
                )
        )
        
        ,tabItem(tabName = "titanicrmd1",
                 h2("Titanic Data Analysis")
                 ,h6("This is a Titanic Passenger File. Now load the file Titanic for analyses.")
                 ,h6("using titanic <- read_csv(\"Titanic_Data.csv\")")
                 ,h3("We have successfully load the csv file of \"Titnic\".")
                 ,h3("Now we will create some graph using ggplot", br(),"The Passenger Class Graph") 
                 ,plotOutput("titnic1")
                 ,h3(br(),"Gender vs Passenger Class")
                 ,plotOutput("titnic2")
                 ,h3(br(),"Port of Embarkation vs Passenger Class")
                 ,plotOutput("titnic3")
                 ,br(),br(),br()
                 
        )
        ,tabItem(tabName = "germanyrmd1",
                 
                 h1("Germany Data Analysis")
                 ,h2("The Federal States which starts from “B”")
                 ,h4("This is All Railway Station File. Now load the file for analyses.")
                 ,h6("using germanyst <- read_csv(\"all_station.csv\")")
                 ,h3("We have successfully load the csv file of \"all_station\".")
                 ,h3("Now we will create some graph using ggplot", br(),"All Station in Federal State") 
                 ,plotOutput("germany1")
                 ,h3(br(),"Category vs Federal State")
                 ,plotOutput("germany2")
                 ,h3(br(),"Regional Bereich Name vs Federal State")
                 ,plotOutput("germany3")
                 ,br(),br(),br()
        )
    )
    
)

shinyApp(
    ui = dashboardPage(
        dashboardHeader(title = "My Dashboard"),
        sidebar,
        body
    ),
    server = function(input, output) { 
        
        output$irisplot <- renderPlot({
            x    <- faithful[, 2]
            bins <- seq(min(x), max(x), length.out = input$bins + 1)
            hist(x, breaks = bins, col = 'darkgray', border = 'white')
        })
        
        output$titnic1 <- renderPlot({
            tt + geom_bar(aes(fill = PassengerClass))+
                labs(title = "Number of Passenger in Different Class",
                     x = "Passenger Class",
                     y = "Count (Passenger)")
        })
        
        output$titnic2 <- renderPlot({
            tt + geom_bar(aes(fill = Sex))+
                labs(title = "Number of Passenger in Different Class",
                     x = "Passenger Class",
                     y = "Count (Passenger)")
        })
        
        output$titnic3 <- renderPlot({
            tt + geom_bar(aes(fill = PortofEmbarkation))
        })
        
        # this is the code block for Germany RMD 1 Tab star
        output$germany1 <- renderPlot({
            federalState + geom_bar(aes(fill = federalState))
        })
        
        output$germany2 <- renderPlot({
            category + geom_bar(aes(fill = federalState))
        })
        
        output$germany3 <- renderPlot({
            federalState + geom_bar(aes(fill = regionalbereichName))
        })
        # this is the code block for Germany RMD 1 Tab end
        

        }
)